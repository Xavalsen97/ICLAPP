package com.example.icl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Hashtable;
import java.util.Map;

public class Registro extends AppCompatActivity {

    String URL_SERVIDOR = "http://192.168.113.49/phpapp/insertar_usuarios.php";

    EditText edtUsuarioR, edtEmailR, edtTelefonoR, edtPasswordR;
    Button buttonReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        edtUsuarioR = findViewById(R.id.edtUsuarioR);
        edtEmailR = findViewById(R.id.edtEmailR);
        edtTelefonoR = findViewById(R.id.edtTelefonoR);
        edtPasswordR = findViewById(R.id.edtPasswordR);
       // edtPasswordR2 = findViewById(R.id.edtPasswordR2);
        buttonReg = findViewById(R.id.buttonReg);

        buttonReg.setOnClickListener(new View.OnClickListener(){
                @Override
            public void onClick(View view){
                    registrar();
                }
        });

    }

    public void registrar(){
        StringRequest stringRequest;
        stringRequest = new StringRequest(Request.Method.POST, URL_SERVIDOR, new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        // En este apartado se programa lo que deseamos hacer en caso de no haber errores
                        if(response.equals("ERROR 1")) {
                            Toast.makeText(Registro.this, "Se deben de llenar todos los campos.", Toast.LENGTH_SHORT).show();
                        } else if(response.equals("ERROR 2")) {
                            Toast.makeText(Registro.this, "Fallo el registro.", Toast.LENGTH_SHORT).show();
                        } else if(response.equals("MENSAJE")) {
                            Toast.makeText(Registro.this, "Registro exitoso.", Toast.LENGTH_LONG).show();
                            finish();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // En caso de tener algun error en la obtencion de los datos
                Toast.makeText(Registro.this, "ERROR CON LA CONEXION", Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                // En este metodo se hace el envio de valores de la aplicacion al servidor
                Map<String, String> parametros = new Hashtable<String, String>();
                parametros.put("nombre", edtUsuarioR.getText().toString().trim());
                parametros.put("telefono", edtTelefonoR.getText().toString().trim());
                parametros.put("password", edtPasswordR.getText().toString().trim());
                parametros.put("correo", edtEmailR.getText().toString().trim());


                return parametros;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Registro.this);
        requestQueue.add(stringRequest);
    }
}

    /*EditText edtUsuarioR, edtEmailR, edtDireciconR, edtPasswordR, edtPasswordR2;
    Button buttonReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        edtUsuarioR=(EditText)findViewById(R.id.edtUsuarioR);
        edtEmailR=(EditText)findViewById(R.id.edtEmailR);
        edtDireciconR=(EditText)findViewById(R.id.edtDireccionR);
        edtPasswordR=(EditText)findViewById(R.id.edtPassword);
        edtPasswordR2=(EditText)findViewById(R.id.edtPasswordR2);

       /* buttonReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    //ejecutarServicio("http://169.254.63.53/phpapp/insertar_usuarios.php");
               // ejecutarServicio("http://192.168.113.49/phpapp/insertar_usuarios.php");
            }
        });*/


    /*}

    public void registrarme (View v){
        ejecutarServicio("http://192.168.113.49/phpapp/insertar_usuarios.php");
    }

    private void ejecutarServicio(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String, String>();
                parametros.put("Usuario",edtUsuarioR.getText().toString());
                parametros.put("Correo", edtEmailR.getText().toString());
                parametros.put("Direccion",edtDireciconR.getText().toString());
                parametros.put("Password",edtPasswordR.getText().toString());
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }*/
