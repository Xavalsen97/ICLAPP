package com.example.icl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Registro extends AppCompatActivity {

    EditText edtUsuarioR, edtEmailR, edtDireciconR, edtPasswordR, edtPasswordR2;
    Button buttonReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        edtUsuarioR=(EditText)findViewById(R.id.edtUsuarioR);
        edtEmailR=(EditText)findViewById(R.id.edtEmailR);
        edtDireciconR=(EditText)findViewById(R.id.edtDireccionR);
        edtPasswordR=(EditText)findViewById(R.id.edtPassword);
        edtPasswordR2=(EditText)findViewById(R.id.edtPasswordR2);

        buttonReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    ejecutarServicio("http://169.254.63.53/phpapp/insertar_usuarios.php");
            }
        });
    }

    private void ejecutarServicio(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String, String>();
                parametros.put("Usuario",edtUsuarioR.getText().toString());
                parametros.put("Correo", edtEmailR.getText().toString());
                parametros.put("Direccion",edtDireciconR.getText().toString());
                parametros.put("Password",edtPasswordR.getText().toString());
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}