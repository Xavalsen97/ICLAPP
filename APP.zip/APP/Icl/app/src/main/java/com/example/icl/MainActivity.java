package com.example.icl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText edtUsuario,edtPassword;
    Button button, button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUsuario=findViewById(R.id.edtUsuario);
        edtPassword=findViewById(R.id.edtPassword);
        Button btn = (Button) findViewById(R.id.button);
        TextView reg = (TextView) findViewById(R.id.Registro);
        TextView rec = (TextView) findViewById(R.id.Recuperar);
        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                //validarUsuario("https://localhost/phpapp/validar_usuario.php");
                //validarUsuario("http://169.254.63.53/phpapp/validar_usuario.php");
                validarUsuario("http://192.168.113.49/phpapp/validar_usuario.php");
                //CORREO: usuario1@gmail.com
                //PASSWORD: holamundo2020
            }

            //Boton sin password ni correo
            /*@Override
            public void onClick(View v) {
                    Intent intent = new Intent (v.getContext(), MenuPrincipal.class);
                    startActivityForResult(intent, 0);
            }*/
        });



        rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent (v.getContext(), Recuperar.class);
                startActivityForResult(intent1, 0);
            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent2 = new Intent (getApplicationContext(), Registro.class);
                startActivity(intent2);
                Toast.makeText(MainActivity.this, "Recuperar", Toast.LENGTH_SHORT).show();
            }
        });

    }

    /*public void registrarse(View v){
        /*TextView reg = (TextView) findViewById(R.id.Registro);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {*/
                /*Intent intent = new Intent (v.getContext(), Registro.class);
                startActivityForResult(intent, 0);
    }*/
        /*});

    }*/

    private void validarUsuario(String URL){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(!response.isEmpty()){
                    Intent intent = new Intent(getApplicationContext(),MenuPrincipal.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(MainActivity.this, "Usuario o constraseña incorrecta", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros=new HashMap<String,String>();
                parametros.put("correo",edtUsuario.getText().toString());
                parametros.put("password",edtPassword.getText().toString());
                return parametros;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

}